var n;
do{
    n = prompt("Ingrese un numero entre 1 y 100")
}while (n <= 100 && n >= 1)